=== Rikki's WP Social Icons ===

Contributors: Rikki Mongoose
Plugin Name: Rikki's WP Social Icons
Plugin URI: http://rikkimongoose.ru/projects/rikkis-wp-social-icons/
Tags: wp, twitter, facebook, blogspot, livejournal, social icons, github
Author URI: http://rikkimongoose.ru/
Author: Rikki Mongoose
Requires at least: 2.5
Tested up to: 3.4.1
Stable tag: 1.0
Version: 1.0 